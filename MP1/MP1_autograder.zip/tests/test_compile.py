import unittest, os
from gradescope_utils.autograder_utils.decorators import weight
from gradescope_utils.autograder_utils.files import check_submitted_files

DRIVER_NAME = 'Drawing.java'

class TestCompile(unittest.TestCase):
    @weight(-50.0)
    def test_compile(self):
        """
        DEDUCTION: CODE DOES NOT COMPILE
        """
        status = os.system(f"javac {DRIVER_NAME}")
        # we annoyingly have to do this backwards
        # to force negative scoring 
        self.assertEqual(status, 256, 'Files compiled successfully!')
        print('Your java file failed to compile.')
